export class Product {
  id!: string;
  name!: string;
  price!: number;
  categoryId!: string;
  img!: string;
  description!: string
}
